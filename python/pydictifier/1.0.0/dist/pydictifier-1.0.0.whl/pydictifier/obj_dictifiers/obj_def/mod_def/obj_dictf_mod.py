# ##############################################################################
# IMPORTS
# ##############################################################################

import pydictifier.core\
        .core_main as core_main
import pydictifier.dictifiers\
        .dictf_main as dictf_main
import pydictifier.obj_dictifiers\
        .obj_dictf_main as obj_dictf_main

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: ObjectDictifier
# ------------------------------------------------------------------------------

class ObjectDictifier(obj_dictf_main.ObjectDictifier):

    # ··········································································
    # Private Method (_dictify_obj_body)
    # ··········································································

    def _dictify_obj_body(self) -> None:

        # Init Object Body Dict

        self._obj_dict_body = {
            "body": {
                "imported_modules": {},
                "dunder_methods": {},
                "builtin_functions_or_methods": {},
                "builtin_datatypes": {},
                "custom_datatypes": {},
                "imported_functions": {},
                "functions": {},
                "imported_classes": {},
                "classes": {},
                "unknown_objects": {}
            }
        }

        # Dictify Object Body Attributes

        for attr_name, attr_value in vars(self._obj.body).items():

            attr_obj = core_main.Object(
                name = attr_name,
                src_module = self._obj.src_module,
                body = attr_value
            )

            # Imported Modules

            if attr_obj.type == core_main.ObjectType.MODULE:
                attr_obj.type = core_main.ObjectType.MODULE_IMPORTED
                self._dictify_attr_obj_body(
                    attr_obj=attr_obj,
                    attr_type="imported_modules"
                )
                continue

            # Dunder Methods

            if attr_obj.type == core_main.ObjectType.DUNDER_METHOD:
                self._dictify_attr_obj_body(
                    attr_obj=attr_obj,
                    attr_type="dunder_methods"
                )
                continue

            # Builtin Functions or Methods

            if attr_obj.type == core_main.ObjectType.BUILTIN_FN_OR_MTD:
                self._dictify_attr_obj_body(
                    attr_obj=attr_obj,
                    attr_type="builtin_functions_or_methods"
                )
                continue

            # Builtin Datatypes

            if attr_obj.type_category == core_main\
                    .ObjectTypeCategory.BUILTIN_DATATYPES:
                self._dictify_attr_obj_body(
                    attr_obj=attr_obj,
                    attr_type="builtin_datatypes"
                )
                continue

            # Custom Datatypes

            if attr_obj.type_category == core_main\
                    .ObjectTypeCategory.CUSTOM_DATATYPES:
                self._dictify_attr_obj_body(
                    attr_obj=attr_obj,
                    attr_type="custom_datatypes"
                )
                continue

            # Functions

            if attr_obj.type == core_main.ObjectType.FUNCTION:
                if attr_obj.src_module != attr_obj.module:
                    attr_obj.type = core_main.ObjectType.FUNCTION_IMPORTED
                    self._dictify_attr_obj_body(
                        attr_obj=attr_obj,
                        attr_type="imported_functions"
                    )
                else:
                    self._dictify_attr_obj_body(
                        attr_obj=attr_obj,
                        attr_type="functions"
                    )
                continue

            # Classes

            if attr_obj.type == core_main.ObjectType.CLASS:
                attr_type = "classes"
                if attr_obj.src_module != attr_obj.module:
                    attr_obj.type = core_main.ObjectType.CLASS_IMPORTED
                    attr_type = "imported_classes"
                self._dictify_attr_obj_body(
                    attr_obj=attr_obj,
                    attr_type=attr_type
                )
                continue

            # Unknown Objects

            self._dictify_attr_obj_body(
                attr_obj=attr_obj,
                attr_type="unknown_objects"
            )

    # ··········································································
    # Private Method (_dictify_attr_obj_body)
    # ··········································································

    def _dictify_attr_obj_body(self, *, attr_obj:core_main.Object,
            attr_type:str) -> None:

        obj_dict = dictf_main.Dictifier.dictify(
            obj=attr_obj,
            metadata=self._metadata
        )

        self._obj_dict_body["body"][attr_type]\
                [attr_obj.name] = obj_dict[attr_obj.name]
