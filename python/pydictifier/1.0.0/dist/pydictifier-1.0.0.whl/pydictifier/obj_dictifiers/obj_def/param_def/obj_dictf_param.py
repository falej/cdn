# ##############################################################################
# IMPORTS
# ##############################################################################

import inspect
import pydictifier.obj_dictifiers\
        .obj_dictf_main as obj_dictf_main

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: ObjectDictifier
# ------------------------------------------------------------------------------

class ObjectDictifier(obj_dictf_main.ObjectDictifier):

    # ··········································································
    # Private Method (_dictify_obj_body)
    # ··········································································

    def _dictify_obj_body(self) -> None:

        # Init Object Body (Dict)

        self._obj_dict_body = {
            "body": {
                "kind": "empty",
                "annotation": "empty",
                "default": "empty"
            }
        }

        # Dictify Object Body (Parameter)

        if not isinstance(self._obj.body, inspect.Parameter):
            self._obj_dict_body["body"]["kind"] = "unknown"
            self._obj_dict_body["body"]["annotation"] = "unknown"
            self._obj_dict_body["body"]["default"] = "unknown"
            return

        if self._obj.body.kind is not inspect.Parameter.empty:
            self._obj_dict_body["body"]\
                    ["kind"] = str(self._obj.body.kind.description)

        if self._obj.body.default is not inspect.Parameter.empty:
            self._obj_dict_body["body"]\
                    ["default"] = str(self._obj.body.default)

        if self._obj.body.annotation is not inspect.Parameter.empty:
            self._obj_dict_body["body"]\
                    ["annotation"] = str(self._obj.body.annotation)
