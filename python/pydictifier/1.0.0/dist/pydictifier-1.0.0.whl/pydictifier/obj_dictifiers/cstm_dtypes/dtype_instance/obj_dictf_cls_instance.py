# ##############################################################################
# IMPORTS
# ##############################################################################

import pydictifier.core\
        .core_main as core_main
import pydictifier.dictifiers\
        .dictf_main as dictf_main
import pydictifier.obj_dictifiers\
        .obj_dictf_main as obj_dictf_main

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: ObjectDictifier
# ------------------------------------------------------------------------------

class ObjectDictifier(obj_dictf_main.ObjectDictifier):

    # ··········································································
    # Private Method (_dictify_obj_body)
    # ··········································································

    def _dictify_obj_body(self) -> None:

        # Init Object Body (Dict)

        self._obj_dict_body = {
            "body": {
                "class": None,
                "class_attributes": {},
                "instance_attributes": {}
            }
        }

        # Dictify Object Body (class)

        cls_name = str(self._obj.body.__class__.__name__)
        cls_module = str(self._obj.body.__class__.__module__)

        cls_obj_name = ".".join((cls_module, cls_name))

        self._obj_dict_body["body"]["class"] = cls_obj_name

        # Dictify Object Body (class_attributes)

        try:
            attrs_dict = vars(self._obj.body.__class__)
        except:
            attrs_dict = {}

        for attr_name, attr_value in attrs_dict.items():

            attr_name = str(attr_name)

            attr_obj = core_main.Object(
                name = attr_name,
                src_module = self._obj.src_module,
                body = attr_value
            )

            if attr_obj.type_category not in (
                core_main.ObjectTypeCategory.BUILTIN_DATATYPES,
                core_main.ObjectTypeCategory.CUSTOM_DATATYPES
            ):
                continue

            attr_obj_dict = dictf_main.Dictifier.dictify(
                obj = attr_obj,
                metadata = self._metadata
            )

            self._obj_dict_body["body"]["class_attributes"]\
                    [attr_name] = attr_obj_dict[attr_name]

        # Dictify Object Body (instance_attributes)

        try:
            attrs_dict = vars(self._obj.body)
        except:
            attrs_dict = {}

        for attr_name, attr_value in attrs_dict.items():

            attr_name = str(attr_name)

            attr_obj = core_main.Object(
                name = attr_name,
                src_module = self._obj.src_module,
                body = attr_value
            )

            if attr_obj.type_category not in (
                core_main.ObjectTypeCategory.BUILTIN_DATATYPES,
                core_main.ObjectTypeCategory.CUSTOM_DATATYPES
            ):
                continue

            attr_obj_dict = dictf_main.Dictifier.dictify(
                obj = attr_obj,
                metadata = self._metadata
            )

            self._obj_dict_body["body"]["instance_attributes"]\
                    [attr_name] = attr_obj_dict[attr_name]
