# ##############################################################################
# IMPORTS
# ##############################################################################

import pydictifier.core\
        .core_main as core_main
import pydictifier.obj_dictifiers\
        .obj_dictf_main as obj_dictf_main

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: ObjectDictifier
# ------------------------------------------------------------------------------

class ObjectDictifier(obj_dictf_main.ObjectDictifier):

    def _dictify_obj_metadata_type(self) -> None:
        self._obj_dict_metadata["type"] =\
                core_main.ObjectType.UNKNOWN.value

    def _dictify_obj_metadata_type_category(self) -> None:
        self._obj_dict_metadata["type_category"] =\
                core_main.ObjectTypeCategory.UNKNOWN.value

    def _dictify_obj_metadata_type_sub_category(self) -> None:
        self._obj_dict_metadata["type_sub_category"] =\
                core_main.ObjectTypeSubCategory.UNKNOWN.value
