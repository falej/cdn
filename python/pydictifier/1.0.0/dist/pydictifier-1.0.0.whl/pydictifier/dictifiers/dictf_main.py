# ##############################################################################
# IMPORTS
# ##############################################################################

import pydictifier.core\
        .core_main as core_main
import pydictifier.dictifiers.obj_def\
        .dictf_obj_def as dictf_obj_def
import pydictifier.dictifiers.bltn_dtypes\
        .dictf_bltn_dtypes as dictf_bltn_dtypes
import pydictifier.dictifiers.cstm_dtypes\
        .dictf_cstm_dtypes as dictf_cstm_dtypes
import pydictifier.dictifiers.unknown\
        .dictf_unknown as dictf_unknown

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: Dictifier
# ------------------------------------------------------------------------------

class Dictifier:

    # ··········································································
    # Static Method (dictify)
    # ··········································································

    @staticmethod
    def dictify(*, obj:core_main.Object=None, metadata:bool=True) -> dict:

        # Dictifier Selection

        match (obj.type_category):
            case core_main.ObjectTypeCategory.OBJECT_DEFINITION:
                dictifier = dictf_obj_def.Dictifier
            case core_main.ObjectTypeCategory.BUILTIN_DATATYPES:
                dictifier = dictf_bltn_dtypes.Dictifier
            case core_main.ObjectTypeCategory.CUSTOM_DATATYPES:
                dictifier = dictf_cstm_dtypes.Dictifier
            case _:
                dictifier = dictf_unknown.Dictifier

        # Object Dictify

        obj_dict = dictifier.dictify(obj=obj, metadata=metadata)

        # End

        return obj_dict
