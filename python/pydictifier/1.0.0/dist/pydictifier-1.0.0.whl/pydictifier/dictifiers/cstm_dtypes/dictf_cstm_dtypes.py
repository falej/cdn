# ##############################################################################
# IMPORTS
# ##############################################################################

import pydictifier.core\
        .core_main as core_main
import pydictifier.dictifiers.cstm_dtypes.dtype_instance\
        .dictf_instance as dictf_instance
import pydictifier.dictifiers.unknown\
        .dictf_unknown as dictf_unknown

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: Dictifier
# ------------------------------------------------------------------------------

class Dictifier:

    # ··········································································
    # Static Method (dictify)
    # ··········································································

    @staticmethod
    def dictify(*, obj:core_main.Object=None, metadata:bool=True) -> dict:

        # Dictifier Selection

        match (obj.type_sub_category):
            case core_main.ObjectTypeSubCategory.DATATYPE_INSTANCE:
                dictifier = dictf_instance.Dictifier
            case _:
                dictifier = dictf_unknown.Dictifier

        # Object Dictify

        obj_dict = dictifier.dictify(obj=obj, metadata=metadata)

        # End

        return obj_dict
