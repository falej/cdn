# ##############################################################################
# IMPORTS
# ##############################################################################

import pydictifier.core\
        .core_main as core_main
import pydictifier.obj_dictifiers.bltn_dtypes.dtype_sequence\
        .obj_dictf_list as obj_dictf_list
import pydictifier.obj_dictifiers.bltn_dtypes.dtype_sequence\
        .obj_dictf_tuple as obj_dictf_tuple
import pydictifier.obj_dictifiers.bltn_dtypes.dtype_sequence\
        .obj_dictf_range as obj_dictf_range
import pydictifier.obj_dictifiers.unknown\
        .obj_dictf_unknown as obj_dictf_unknown

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: Dictifier
# ------------------------------------------------------------------------------

class Dictifier:

    # ··········································································
    # Static Method (dictify)
    # ··········································································

    @staticmethod
    def dictify(*, obj:core_main.Object=None, metadata:bool=True) -> dict:

        # Dictifier Selection

        match (obj.type):
            case core_main.ObjectType.LIST:
                obj_dictifier = obj_dictf_list.ObjectDictifier(
                        obj=obj, metadata=metadata)
            case core_main.ObjectType.TUPLE:
                obj_dictifier = obj_dictf_tuple.ObjectDictifier(
                        obj=obj, metadata=metadata)
            case core_main.ObjectType.RANGE:
                obj_dictifier = obj_dictf_range.ObjectDictifier(
                        obj=obj, metadata=metadata)
            case _:
                obj_dictifier = obj_dictf_unknown.ObjectDictifier(
                        obj=obj, metadata=metadata)

        # Object Dictify

        obj_dict = obj_dictifier.dictify()

        # End

        return obj_dict
