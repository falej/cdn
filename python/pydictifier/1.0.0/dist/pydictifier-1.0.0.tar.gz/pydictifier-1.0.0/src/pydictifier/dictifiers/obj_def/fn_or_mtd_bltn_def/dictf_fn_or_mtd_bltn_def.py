# ##############################################################################
# IMPORTS
# ##############################################################################

import pydictifier.core\
        .core_main as core_main
import pydictifier.obj_dictifiers.obj_def.fn_or_mtd_bltn_def\
        .obj_dictf_fn_or_mtd_bltn_def as obj_dictf_fn_or_mtd_bltn_def
import pydictifier.obj_dictifiers.obj_def.fn_or_mtd_bltn_def\
        .obj_dictf_dunder_mtd as obj_dictf_dunder_mtd
import pydictifier.obj_dictifiers.unknown\
        .obj_dictf_unknown as obj_dictf_unknown

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: Dictifier
# ------------------------------------------------------------------------------

class Dictifier:

    # ··········································································
    # Static Method (dictify)
    # ··········································································

    @staticmethod
    def dictify(*, obj:core_main.Object=None, metadata:bool=True) -> dict:

        # Dictifier Selection

        match (obj.type):
            case core_main.ObjectType.BUILTIN_FN_OR_MTD:
                obj_dictifier = obj_dictf_fn_or_mtd_bltn_def.ObjectDictifier(
                        obj=obj, metadata=metadata)
            case core_main.ObjectType.DUNDER_METHOD:
                obj_dictifier = obj_dictf_dunder_mtd.ObjectDictifier(
                        obj=obj, metadata=metadata)
            case _:
                obj_dictifier = obj_dictf_unknown.ObjectDictifier(
                        obj=obj, metadata=metadata)

        # Object Dictify

        obj_dict = obj_dictifier.dictify()

        # End

        return obj_dict
