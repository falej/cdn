# ##############################################################################
# IMPORTS
# ##############################################################################

import pydictifier.core\
        .core_main as core_main
import pydictifier.dictifiers\
        .dictf_main as dictf_main
import pydictifier.obj_dictifiers\
        .obj_dictf_main as obj_dictf_main

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: ObjectDictifier
# ------------------------------------------------------------------------------

class ObjectDictifier(obj_dictf_main.ObjectDictifier):

    # ··········································································
    # Private Method (_dictify_obj_body)
    # ··········································································

    def _dictify_obj_body(self) -> None:

        # Init Object Body (Dict)

        self._obj_dict_body = { "body": {} }

        # Dictify Object Body (Items)

        for index, item in enumerate(self._obj.body):

            item_obj = core_main.Object(
                name = str(index),
                src_module = self._obj.src_module,
                body = item
            )

            item_obj_dict = dictf_main.Dictifier.dictify(
                obj = item_obj,
                metadata = self._metadata
            )

            self._obj_dict_body["body"][str(index)] = item_obj_dict[str(index)]
