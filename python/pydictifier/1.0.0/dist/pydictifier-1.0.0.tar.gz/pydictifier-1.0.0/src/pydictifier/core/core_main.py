# ##############################################################################
# IMPORTS
# ##############################################################################

import sys
import inspect
import enum
import types
import typing
import pydantic

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: ObjectTypeCategory
# ------------------------------------------------------------------------------

class ObjectTypeCategory(enum.Enum):

    OBJECT_DEFINITION = "object_definition"
    BUILTIN_DATATYPES = "builtin_datatypes"
    CUSTOM_DATATYPES = "custom_datatypes"
    UNKNOWN = "unknown"

# ------------------------------------------------------------------------------
# Class: ObjectTypeSubCategory
# ------------------------------------------------------------------------------

class ObjectTypeSubCategory(enum.Enum):

    # Category: Object Definition

    MODULE_DEFINITION = "module_definition"
    CLASS_DEFINITION = "class_definition"
    FN_OR_MTD_BUILTIN_DEFINITION = (
            "fn_or_mtd_builtin_definition")
    FN_OR_MTD_CUSTOM_DEFINITION = (
            "fn_or_mtd_custom_definition")
    PARAMETER_DEFINITION = "parameter_definition"

    # Category: Builtin Datatypes

    DATATYPE_NUMERIC = "datatype_numeric"
    DATATYPE_STRING = "datatype_string"
    DATATYPE_SEQUENCE = "datatype_sequence"
    DATATYPE_SET = "datatype_set"
    DATATYPE_MAPPING = "datatype_mapping"
    DATATYPE_BOOLEAN = "datatype_boolean"
    DATATYPE_BINARY = "datatype_binary"
    DATATYPE_NONE = "datatype_none"

    # Category: Custom Datatypes

    DATATYPE_INSTANCE = "datatype_instance"

    # Category: Unknown

    UNKNOWN = "unknown"

# ------------------------------------------------------------------------------
# Class: ObjectType
# ------------------------------------------------------------------------------

class ObjectType(enum.Enum):

    # SubCategory: Module Definition

    MODULE = "module"
    MODULE_IMPORTED = "module_imported"

    # SubCategory: Class Definition

    CLASS = "class"
    CLASS_INNER = "class_inner"
    CLASS_IMPORTED = "class_imported"

    # SubCategory: Function or Method (Builtin Definition)

    BUILTIN_FN_OR_MTD = "builtin_function_or_method"
    DUNDER_METHOD = "dunder_method"

    # SubCategory: Function or Method (Custom Definition)

    STATIC_METHOD = "static_method"
    CLASS_METHOD = "class_method"
    FUNCTION = "function"
    FUNCTION_IMPORTED = "function_imported"

    # SubCategory: Parameter Definition

    PARAMETER = "parameter"

    # SubCategory: Builtin Datatype (Numeric)

    INTEGER = "integer"
    FLOAT = "float"
    COMPLEX = "complex"

    # SubCategory: Builtin Datatype (String)

    STRING = "string"

    # SubCategory: Builtin Datatype (Sequence)

    LIST = "list"
    TUPLE = "tuple"
    RANGE = "range"

    # SubCategory: Builtin Datatype (Set)

    SET = "set"
    FROZENSET = "frozenset"

    # SubCategory: Builtin Datatype (Mapping)

    DICTIONARY = "dictionary"

    # SubCategory: Builtin Datatype (Boolean)

    BOOLEAN = "boolean"

    # SubCategory: Builtin Datatype (Binary)

    BYTES = "bytes"
    BYTE_ARRAY = "byte_array"
    MEMORY_VIEW = "memory_view"

    # SubCategory: Builtin Datatype (None)

    NONE = "none"

    # SubCategory: Custom Datatype (Class Instance)

    CLASS_INSTANCE = "class_instance"

    # SubCategory: Unknown

    UNKNOWN = "unknown"

# ------------------------------------------------------------------------------
# Class: ObjectTypeMapper
# ------------------------------------------------------------------------------

class ObjectTypeCategorizer:

    @staticmethod
    def categorize(*, obj_type:ObjectType=ObjectType.UNKNOWN) -> dict:

        obj_cat_map = {
            ObjectType.MODULE: {
                "type_category": ObjectTypeCategory.OBJECT_DEFINITION,
                "type_sub_category": ObjectTypeSubCategory.MODULE_DEFINITION
            },
            ObjectType.MODULE_IMPORTED: {
                "type_category": ObjectTypeCategory.OBJECT_DEFINITION,
                "type_sub_category": ObjectTypeSubCategory.MODULE_DEFINITION
            },
            ObjectType.CLASS: {
                "type_category": ObjectTypeCategory.OBJECT_DEFINITION,
                "type_sub_category": ObjectTypeSubCategory.CLASS_DEFINITION
            },
            ObjectType.CLASS_INNER: {
                "type_category": ObjectTypeCategory.OBJECT_DEFINITION,
                "type_sub_category": ObjectTypeSubCategory.CLASS_DEFINITION
            },
            ObjectType.CLASS_IMPORTED: {
                "type_category": ObjectTypeCategory.OBJECT_DEFINITION,
                "type_sub_category": ObjectTypeSubCategory.CLASS_DEFINITION
            },
            ObjectType.BUILTIN_FN_OR_MTD: {
                "type_category": ObjectTypeCategory.OBJECT_DEFINITION,
                "type_sub_category": (
                    ObjectTypeSubCategory.FN_OR_MTD_BUILTIN_DEFINITION)
            },
            ObjectType.DUNDER_METHOD: {
                "type_category": ObjectTypeCategory.OBJECT_DEFINITION,
                "type_sub_category": (
                    ObjectTypeSubCategory.FN_OR_MTD_BUILTIN_DEFINITION)
            },
            ObjectType.STATIC_METHOD: {
                "type_category": ObjectTypeCategory.OBJECT_DEFINITION,
                "type_sub_category": (
                    ObjectTypeSubCategory.FN_OR_MTD_CUSTOM_DEFINITION)
            },
            ObjectType.CLASS_METHOD: {
                "type_category": ObjectTypeCategory.OBJECT_DEFINITION,
                "type_sub_category": (
                    ObjectTypeSubCategory.FN_OR_MTD_CUSTOM_DEFINITION)
            },
            ObjectType.FUNCTION: {
                "type_category": ObjectTypeCategory.OBJECT_DEFINITION,
                "type_sub_category": (
                    ObjectTypeSubCategory.FN_OR_MTD_CUSTOM_DEFINITION)
            },
            ObjectType.FUNCTION_IMPORTED: {
                "type_category": ObjectTypeCategory.OBJECT_DEFINITION,
                "type_sub_category": (
                    ObjectTypeSubCategory.FN_OR_MTD_CUSTOM_DEFINITION)
            },
            ObjectType.PARAMETER: {
                "type_category": ObjectTypeCategory.OBJECT_DEFINITION,
                "type_sub_category": ObjectTypeSubCategory.PARAMETER_DEFINITION
            },
            ObjectType.INTEGER: {
                "type_category": ObjectTypeCategory.BUILTIN_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_NUMERIC
            },
            ObjectType.FLOAT: {
                "type_category": ObjectTypeCategory.BUILTIN_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_NUMERIC
            },
            ObjectType.COMPLEX: {
                "type_category": ObjectTypeCategory.BUILTIN_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_NUMERIC
            },
            ObjectType.STRING: {
                "type_category": ObjectTypeCategory.BUILTIN_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_STRING
            },
            ObjectType.LIST: {
                "type_category": ObjectTypeCategory.BUILTIN_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_SEQUENCE
            },
            ObjectType.TUPLE: {
                "type_category": ObjectTypeCategory.BUILTIN_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_SEQUENCE
            },
            ObjectType.RANGE: {
                "type_category": ObjectTypeCategory.BUILTIN_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_SEQUENCE
            },
            ObjectType.SET: {
                "type_category": ObjectTypeCategory.BUILTIN_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_SET
            },
            ObjectType.FROZENSET: {
                "type_category": ObjectTypeCategory.BUILTIN_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_SET
            },
            ObjectType.DICTIONARY: {
                "type_category": ObjectTypeCategory.BUILTIN_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_MAPPING
            },
            ObjectType.BOOLEAN: {
                "type_category": ObjectTypeCategory.BUILTIN_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_BOOLEAN
            },
            ObjectType.BYTES: {
                "type_category": ObjectTypeCategory.BUILTIN_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_BINARY
            },
            ObjectType.BYTE_ARRAY: {
                "type_category": ObjectTypeCategory.BUILTIN_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_BINARY
            },
            ObjectType.MEMORY_VIEW: {
                "type_category": ObjectTypeCategory.BUILTIN_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_BINARY
            },
            ObjectType.NONE: {
                "type_category": ObjectTypeCategory.BUILTIN_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_NONE
            },
            ObjectType.CLASS_INSTANCE: {
                "type_category": ObjectTypeCategory.CUSTOM_DATATYPES,
                "type_sub_category": ObjectTypeSubCategory.DATATYPE_INSTANCE
            },
            ObjectType.UNKNOWN: {
                "type_category": ObjectTypeCategory.UNKNOWN,
                "type_sub_category": ObjectTypeSubCategory.UNKNOWN
            }
        }

        return obj_cat_map.get(obj_type, obj_cat_map[ObjectType.UNKNOWN])

# ------------------------------------------------------------------------------
# Class: ObjectModel
# ------------------------------------------------------------------------------

class ObjectModel(pydantic.BaseModel):

    # Model Config

    model_config = pydantic.ConfigDict(
        arbitrary_types_allowed = True,
        extra = "forbid"
    )

    # Model Fields

    name:str

    src_module:types.ModuleType
    src_file:str|None

    body:typing.Any|None = None

    module:types.ModuleType|None
    file:str|None

    type:ObjectType
    type_category:ObjectTypeCategory
    type_sub_category:ObjectTypeSubCategory

class ObjectParamsModel(pydantic.BaseModel):

    # Model Config

    model_config = pydantic.ConfigDict(
        arbitrary_types_allowed = True,
        extra = "forbid"
    )

    # Model Fields

    name:str
    src_module:types.ModuleType
    body:typing.Any|None = None

    # Model Validators

    @pydantic.field_validator("name")
    def validate_name(cls, value:str) -> str:

        if len(value.strip()) == 0:
            raise ValueError("Missing or Invalid.")

        return value

# ------------------------------------------------------------------------------
# Class: Object
# ------------------------------------------------------------------------------

class Object:

    # ··········································································
    # Constructor
    # ··········································································

    def __init__(self, *, name:str=None, src_module:types.ModuleType=None,
                 body:typing.Any=None) -> None:

        self._validate_params(name=name, src_module=src_module, body=body)

        # Init Attributes

        self._name = name.strip()

        self._src_module = src_module
        self._src_file = None

        self._body = body

        self._module = None
        self._file = None

        self._type = ObjectType.UNKNOWN
        self._type_category = ObjectTypeCategory.UNKNOWN
        self._type_sub_category = ObjectTypeSubCategory.UNKNOWN

        # Set Attributes

        self._set_attr_src_file()
        self._set_attr_module()
        self._set_attr_file()
        self._set_attr_type()
        self._set_attr_type_categories()

        # Validate Attributes

        self._validate_attributes()

    # ··········································································
    # Accessor Methods (name)
    # ··········································································

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value:str) -> None:
        self._name = value.strip()
        self._validate_attributes()

    # ··········································································
    # Accessor Methods (src_module)
    # ··········································································

    @property
    def src_module(self) -> types.ModuleType:
        return self._src_module

    @src_module.setter
    def src_module(self, value:types.ModuleType) -> None:
        self._src_module = value
        self._set_attr_src_file()
        self._validate_attributes()

    # ··········································································
    # Accessor Methods (src_file)
    # ··········································································

    @property
    def src_file(self) -> str:
        return self._src_file

    @src_file.setter
    def src_file(self, value:str) -> None:
        raise AttributeError("Attribute <src_file> cannot be modified.")

    # ··········································································
    # Accessor Methods (body)
    # ··········································································

    @property
    def body(self) -> typing.Any:
        return self._body

    @body.setter
    def body(self, value:typing.Any) -> None:
        self._body = value
        self._set_attr_module()
        self._set_attr_file()
        self._validate_attributes()

    # ··········································································
    # Accessor Methods (module)
    # ··········································································

    @property
    def module(self) -> types.ModuleType:
        return self._module

    @module.setter
    def module(self, value:types.ModuleType) -> None:
        raise AttributeError("Attribute <module> cannot be modified.")

    # ··········································································
    # Accessor Methods (file)
    # ··········································································

    @property
    def file(self) -> str:
        return self._file

    @file.setter
    def file(self, value:str) -> None:
        raise AttributeError("Attribute <file> cannot be modified.")

    # ··········································································
    # Accessor Methods (type)
    # ··········································································

    @property
    def type(self) -> ObjectType:
        return self._type

    @type.setter
    def type(self, value:ObjectType) -> None:
        self._type = value
        self._set_attr_type_categories()
        self._validate_attributes()

    # ··········································································
    # Accessor Methods (type_category)
    # ··········································································

    @property
    def type_category(self) -> ObjectTypeCategory:
        return self._type_category

    @type_category.setter
    def type_category(self, value:ObjectTypeCategory) -> None:
        raise AttributeError("Attribute <type_category> cannot be modified.")

    # ··········································································
    # Accessor Methods (type_sub_category)
    # ··········································································

    @property
    def type_sub_category(self) -> ObjectTypeSubCategory:
        return self._type_sub_category

    @type_sub_category.setter
    def type_sub_category(self, value:ObjectTypeSubCategory) -> None:
        raise AttributeError(
                "Attribute <type_sub_category> cannot be modified.")

    # ··········································································
    # Private Method (_validate_params)
    # ··········································································

    def _validate_params(self, *, name:str, src_module:types.ModuleType,
                         body:typing.Any) -> None:

        ObjectParamsModel.model_validate({
            "name": name,
            "src_module": src_module,
            "body": body
        })

    # ··········································································
    # Private Method (_validate_attributes)
    # ··········································································

    def _validate_attributes(self) -> None:

        ObjectModel.model_validate({
            "name": self._name,
            "src_module": self._src_module,
            "src_file": self._src_file,
            "body": self._body,
            "module": self._module,
            "file": self._file,
            "type": self._type,
            "type_category": self._type_category,
            "type_sub_category": self._type_sub_category
        })

    # ··········································································
    # Private Method (_set_attr_src_file)
    # ··········································································

    def _set_attr_src_file(self) -> None:

        if self._src_module is not None:
            self._src_file = self._src_module.__file__\
                    if hasattr(self._src_module, "__file__") else None

        self._validate_attributes()

    # ··········································································
    # Private Method (_init_attr_module)
    # ··········································································

    def _set_attr_module(self) -> None:

        unwrapped_body = inspect.unwrap(self._body)

        if hasattr(unwrapped_body, "__func__"):
            unwrapped_body = unwrapped_body.__func__

        if inspect.ismodule(unwrapped_body):
            self._module = unwrapped_body
        else:
            try:
                self._module = sys.modules[unwrapped_body.__module__]
            except:
                pass

        self._validate_attributes()

    # ··········································································
    # Private Method (_init_attr_file)
    # ··········································································

    def _set_attr_file(self) -> None:

        if self._module is not None:
            self._file = self._module.__file__\
                    if hasattr(self._module, "__file__") else None

        self._validate_attributes()

    # ··········································································
    # Private Method (_init_attr_types)
    # ··········································································

    def _set_attr_type(self) -> None:

        if self._is_module():
            self._type = ObjectType.MODULE

        elif self._is_class():
            self._type = ObjectType.CLASS

        elif self._is_builtin_function_or_method():
            self._type = ObjectType.BUILTIN_FN_OR_MTD

        elif self._is_dunder_method():
            self._type = ObjectType.DUNDER_METHOD

        elif self._is_static_method():
            self._type = ObjectType.STATIC_METHOD

        elif self._is_class_method():
            self._type = ObjectType.CLASS_METHOD

        elif self._is_function():
            self._type = ObjectType.FUNCTION

        elif self._is_integer():
            self._type = ObjectType.INTEGER

        elif self._is_float():
            self._type = ObjectType.FLOAT

        elif self._is_complex():
            self._type = ObjectType.COMPLEX

        elif self._is_string():
            self._type = ObjectType.STRING

        elif self._is_list():
            self._type = ObjectType.LIST

        elif self._is_tuple():
            self._type = ObjectType.TUPLE

        elif self._is_range():
            self._type = ObjectType.RANGE

        elif self._is_set():
            self._type = ObjectType.SET

        elif self._is_frozenset():
            self._type = ObjectType.FROZENSET

        elif self._is_dictionary():
            self._type = ObjectType.DICTIONARY

        elif self._is_boolean():
            self._type = ObjectType.BOOLEAN

        elif self._is_bytes():
            self._type = ObjectType.BYTES

        elif self._is_byte_array():
            self._type = ObjectType.BYTE_ARRAY

        elif self._is_memory_view():
            self._type = ObjectType.MEMORY_VIEW

        elif self._is_none():
            self._type = ObjectType.NONE

        elif self._is_class_instance():
            self._type = ObjectType.CLASS_INSTANCE

        else:
            self._type = ObjectType.UNKNOWN

    # ··········································································
    # Private Method (_set_attr_type_categories)
    # ··········································································

    def _set_attr_type_categories(self) -> None:

        obj_types = ObjectTypeCategorizer.categorize(obj_type=self._type)

        self._type_category = obj_types["type_category"]
        self._type_sub_category = obj_types["type_sub_category"]

    # ··········································································
    # Private Method (_is_module)
    # ··········································································

    def _is_module(self) -> bool:
        return inspect.ismodule(self.body)

    # ··········································································
    # Private Method (_is_class)
    # ··········································································

    def _is_class(self) -> bool:
        return inspect.isclass(self.body)

    # ··········································································
    # Private Method (_is_dunder_method)
    # ··········································································

    def _is_dunder_method(self):
        return (
            self.name.startswith("__") and
            self.name.endswith("__")
        )

    # ··········································································
    # Private Method (_is_builtin_function_or_method)
    # ··········································································

    def _is_builtin_function_or_method(self):
        return inspect.isbuiltin(self.body)

    # ··········································································
    # Private Method (_is_static_method)
    # ··········································································

    def _is_static_method(self):
        return type(self.body).__name__ == "staticmethod"

    # ··········································································
    # Private Method (_is_class_method)
    # ··········································································

    def _is_class_method(self):
        return type(self.body).__name__ == "classmethod"

    # ··········································································
    # Private Method (_is_function)
    # ··········································································

    def _is_function(self):

        is_callable = callable(self.body)
        is_fn_or_mtd = type(self.body).__name__ in ("function", "method")
        is_not_builtin_fn_or_mtd = not self._is_builtin_function_or_method()
        is_not_static_method = not self._is_static_method()
        is_not_class_method = not self._is_class_method()

        return (is_callable and is_fn_or_mtd and is_not_builtin_fn_or_mtd and
                is_not_static_method and is_not_class_method)

    # ··········································································
    # Private Method (_is_integer)
    # ··········································································

    def _is_integer(self):
        return isinstance(self.body, int) and (type(self.body) is int)

    # ··········································································
    # Private Method (_is_float)
    # ··········································································

    def _is_float(self):
        return isinstance(self.body, float) and (type(self.body) is float)

    # ··········································································
    # Private Method (_is_complex)
    # ··········································································

    def _is_complex(self):
        return isinstance(self.body, complex) and (type(self.body) is complex)

    # ··········································································
    # Private Method (_is_string)
    # ··········································································

    def _is_string(self):
        return isinstance(self.body, str) and (type(self.body) is str)

    # ··········································································
    # Private Method (_is_list)
    # ··········································································

    def _is_list(self):
        return isinstance(self.body, list) and (type(self.body) is list)

    # ··········································································
    # Private Method (_is_tuple)
    # ··········································································

    def _is_tuple(self):
        return isinstance(self.body, tuple) and (type(self.body) is tuple)

    # ··········································································
    # Private Method (_is_range)
    # ··········································································

    def _is_range(self):
        return isinstance(self.body, range) and (type(self.body) is range)

    # ··········································································
    # Private Method (_is_set)
    # ··········································································

    def _is_set(self):
        return isinstance(self.body, set) and (type(self.body) is set)

    # ··········································································
    # Private Method (_is_frozenset)
    # ··········································································

    def _is_frozenset(self):
        return isinstance(self.body, frozenset) and \
               (type(self.body) is frozenset)

    # ··········································································
    # Private Method (_is_dictionary)
    # ··········································································

    def _is_dictionary(self):
        return isinstance(self.body, dict) and (type(self.body) is dict)

    # ··········································································
    # Private Method (_is_boolean)
    # ··········································································

    def _is_boolean(self):
        return isinstance(self.body, bool) and (type(self.body) is bool)

    # ··········································································
    # Private Method (_is_bytes)
    # ··········································································

    def _is_bytes(self):
        return isinstance(self.body, bytes) and (type(self.body) is bytes)

    # ··········································································
    # Private Method (_is_byte_array)
    # ··········································································

    def _is_byte_array(self):
        return isinstance(self.body, bytearray) and \
               (type(self.body) is bytearray)

    # ··········································································
    # Private Method (_is_memory_view)
    # ··········································································

    def _is_memory_view(self):
        return isinstance(self.body, memoryview) and \
               (type(self.body) is memoryview)

    # ··········································································
    # Private Method (_is_none)
    # ··········································································

    def _is_none(self):
        return isinstance(self.body, type(None))

    # ··········································································
    # Private Method (_is_class_instance)
    # ··········································································

    def _is_class_instance(self):
        return (
            isinstance(self.body, object) and
            not isinstance(self.body, type) and
            not self._is_module() and
            not self._is_class() and
            not self._is_dunder_method() and
            not self._is_builtin_function_or_method() and
            not self._is_static_method() and
            not self._is_class_method() and
            not self._is_function() and
            not self._is_integer() and
            not self._is_float() and
            not self._is_complex() and
            not self._is_string() and
            not self._is_list() and
            not self._is_tuple() and
            not self._is_range() and
            not self._is_set() and
            not self._is_frozenset() and
            not self._is_dictionary() and
            not self._is_boolean() and
            not self._is_bytes() and
            not self._is_byte_array() and
            not self._is_memory_view() and
            not self._is_none()
        )
