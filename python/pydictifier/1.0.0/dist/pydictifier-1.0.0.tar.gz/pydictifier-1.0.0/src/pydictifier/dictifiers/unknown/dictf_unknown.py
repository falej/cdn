# ##############################################################################
# IMPORTS
# ##############################################################################

import pydictifier.core\
        .core_main as core_main
import pydictifier.obj_dictifiers.unknown\
        .obj_dictf_unknown as obj_dictf_unknown

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: Dictifier
# ------------------------------------------------------------------------------

class Dictifier:

    # ··········································································
    # Static Method (dictify)
    # ··········································································

    @staticmethod
    def dictify(*, obj:core_main.Object=None, metadata:bool=True) -> dict:

        # Object Dictifier
        obj_dictifier = obj_dictf_unknown.ObjectDictifier(
                obj=obj, metadata=metadata)

        # Object Dictify

        obj_dict = obj_dictifier.dictify()

        # End

        return obj_dict
