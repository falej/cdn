# ##############################################################################
# IMPORTS
# ##############################################################################

import inspect
import pydictifier.core\
        .core_main as core_main
import pydictifier.dictifiers\
        .dictf_main as dictf_main
import pydictifier.obj_dictifiers\
        .obj_dictf_main as obj_dictf_main

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: ObjectDictifier
# ------------------------------------------------------------------------------

class ObjectDictifier(obj_dictf_main.ObjectDictifier):

    # ··········································································
    # Private Method (_dictify_obj_body)
    # ··········································································

    def _dictify_obj_body(self) -> None:

        # Init Object Body (Dict)

        self._obj_dict_body = {
            "body": {
                "imported_modules": {},
                "class_attributes": {},
                "instance_attributes": {},
                "dunder_methods": {},
                "builtin_functions_or_methods": {},
                "static_methods": {},
                "class_methods": {},
                "instance_methods": {},
                "imported_functions": {},
                "imported_classes": {},
                "inner_classes": {},
                "unknown_objects": {}
            }
        }

        # Dictify Object Body (Attributes)

        for attr_name, attr_value in vars(self._obj.body).items():

            attr_obj = core_main.Object(
                name = attr_name,
                src_module = self._obj.src_module,
                body = attr_value
            )

            # Imported Modules

            if attr_obj.type == core_main.ObjectType.MODULE:
                attr_obj.type = core_main.ObjectType.MODULE_IMPORTED
                self._dictify_attr_obj_body(
                    attr_obj=attr_obj,
                    attr_type="imported_modules"
                )
                continue

            # Class Attributes

            if attr_obj.type_category in (
                core_main.ObjectTypeCategory.BUILTIN_DATATYPES,
                core_main.ObjectTypeCategory.CUSTOM_DATATYPES
            ):
                self._dictify_attr_obj_body(
                    attr_obj=attr_obj,
                    attr_type="class_attributes"
                )
                continue

            # Dunder Methods

            if attr_obj.type == core_main.ObjectType.DUNDER_METHOD:
                self._dictify_attr_obj_body(
                    attr_obj=attr_obj,
                    attr_type="dunder_methods"
                )
                continue

            # Builtin Functions or Methods

            if attr_obj.type == core_main.ObjectType.BUILTIN_FN_OR_MTD:
                self._dictify_attr_obj_body(
                    attr_obj=attr_obj,
                    attr_type="builtin_functions_or_methods"
                )
                continue

            # Static Methods

            if attr_obj.type == core_main.ObjectType.STATIC_METHOD:
                self._dictify_attr_obj_body(
                    attr_obj=attr_obj,
                    attr_type="static_methods"
                )
                continue

            # Class Methods

            if attr_obj.type == core_main.ObjectType.CLASS_METHOD:
                self._dictify_attr_obj_body(
                    attr_obj=attr_obj,
                    attr_type="class_methods"
                )
                continue

            # Instance Methods / Imported Functions

            if attr_obj.type == core_main.ObjectType.FUNCTION:
                if attr_obj.src_module != attr_obj.module:
                    attr_obj.type = core_main.ObjectType.FUNCTION_IMPORTED
                    self._dictify_attr_obj_body(
                        attr_obj=attr_obj,
                        attr_type="imported_functions"
                    )
                else:
                    self._dictify_attr_obj_body(
                        attr_obj=attr_obj,
                        attr_type="instance_methods"
                    )
                continue

            # Imported/Inner Classes

            if attr_obj.type == core_main.ObjectType.CLASS:
                attr_obj.type = core_main.ObjectType.CLASS_INNER
                attr_type = "inner_classes"
                if attr_obj.src_module != attr_obj.module:
                    attr_obj.type = core_main.ObjectType.CLASS_IMPORTED
                    attr_type = "imported_classes"
                self._dictify_attr_obj_body(
                    attr_obj=attr_obj,
                    attr_type=attr_type
                )
                continue

            # Unknown Objects

            self._dictify_attr_obj_body(
                attr_obj=attr_obj,
                attr_type="unknown_objects"
            )

        # Dictify Object Body (Instance Attributes)

        self._dictify_obj_body_instance_attributes()

    # ··········································································
    # Private Method (_dictify_attr_obj_body)
    # ··········································································

    def _dictify_attr_obj_body(self, *, attr_obj:core_main.Object,
            attr_type:str) -> None:

        obj_dict = dictf_main.Dictifier.dictify(
            obj=attr_obj,
            metadata=self._metadata
        )

        self._obj_dict_body["body"][attr_type]\
                [attr_obj.name] = obj_dict[attr_obj.name]

    # ··········································································
    # Private Method (_dictify_obj_body_instance_attributes)
    # ··········································································

    def _dictify_obj_body_instance_attributes(self) -> None:


        cls_instance_attrs = {}

        try:

            cls_params = inspect.signature(self._obj.body).parameters

            args = ()
            kwargs = {}

            for p_name in cls_params.keys():
                p_obj = cls_params[p_name]
                p_value = p_obj.default\
                            if (p_obj.default != inspect.Parameter.empty)\
                            else None
                if p_obj.kind in (
                        inspect.Parameter.POSITIONAL_ONLY,
                        inspect.Parameter.POSITIONAL_OR_KEYWORD
                ):
                    args += (p_value,)
                else:
                    kwargs[p_name] = p_value

            cls_instance = self._obj.body(*args, **kwargs)

            cls_instance_attrs = {
                k:v
                for k,v in vars(cls_instance).items()
                if not k.startswith("__") and not k.endswith("__")
            }

        except:
            pass

        for cls_attr_name, cls_attr_value in cls_instance_attrs.items():

            cls_attr_obj = core_main.Object(
                name = cls_attr_name,
                src_module = self._obj.src_module,
                body = cls_attr_value
            )

            cls_attr_obj_dict = dictf_main.Dictifier.dictify(
                obj=cls_attr_obj,
                metadata=self._metadata
            )

            self._obj_dict_body["body"]["instance_attributes"]\
                [cls_attr_name] = cls_attr_obj_dict[cls_attr_name]
