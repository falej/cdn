# ##############################################################################
# IMPORTS
# ##############################################################################

import inspect
import pydictifier.core\
        .core_main as core_main
import pydictifier.dictifiers\
        .dictf_main as dictf_main
import pydictifier.obj_dictifiers\
        .obj_dictf_main as obj_dictf_main

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: ObjectDictifier
# ------------------------------------------------------------------------------

class ObjectDictifier(obj_dictf_main.ObjectDictifier):

    # ··········································································
    # Private Method (_dictify_obj_body)
    # ··········································································

    def _dictify_obj_body(self) -> None:

        # Init Object Body Dict

        self._obj_dict_body = {
            "body": {
                "parameters": {}
            }
        }

        # Dictify Object Body Parameters

        try:

            fn_unwrapped = inspect.unwrap(self._obj.body)
            fn_signature = inspect.signature(fn_unwrapped)

            fn_params = fn_signature.parameters

            for fn_param_name, fn_param in fn_params.items():

                fn_param_obj = core_main.Object(
                    name = fn_param_name,
                    src_module = self._obj.src_module,
                    body = fn_param
                )

                fn_param_obj.type = core_main.ObjectType.PARAMETER

                fn_param_obj_dict = dictf_main.Dictifier.dictify(
                    obj=fn_param_obj,
                    metadata=self._metadata
                )

                self._obj_dict_body["body"]["parameters"]\
                    [fn_param_name] = fn_param_obj_dict[fn_param_name]

        except:
            pass
