# ##############################################################################
# IMPORTS
# ##############################################################################

import pydantic
import pydictifier.core\
        .core_main as core_main

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: ObjectDictifierParamsModel
# ------------------------------------------------------------------------------

class ObjectDictifierParamsModel(pydantic.BaseModel):

    # Model Config

    model_config = pydantic.ConfigDict(
        arbitrary_types_allowed = True,
        extra = "forbid"
    )

    # Model Fields

    obj:core_main.Object
    metadata:bool=True

# ------------------------------------------------------------------------------
# Class: ObjectDictifier
# ------------------------------------------------------------------------------

class ObjectDictifier:

    # ··········································································
    # Constructor
    # ··········································································

    def __init__(self, *, obj:core_main.Object, metadata:bool=True) -> None:

        self._validate_params(obj=obj, metadata=metadata)

        # Init Attributes

        self._obj = obj
        self._metadata = metadata

        self._obj_dict_metadata = None
        self._obj_dict_body = None

    # ··········································································
    # Accessor Methods (obj)
    # ··········································································

    @property
    def obj(self) -> core_main.Object:
        return self._obj

    # ··········································································
    # Accessor Methods (metadata)
    # ··········································································

    @property
    def metadata(self) -> bool:
        return self._metadata

    # ··········································································
    # Public Method (dictify)
    # ··········································································

    def dictify(self) -> dict:

        self._dictify_obj_metadata()
        self._dictify_obj_body()

        return\
            { self._obj.name: self._obj_dict_metadata | self._obj_dict_body }\
            if self._metadata\
            else { self._obj.name: self._obj_dict_body["body"] }

    # ··········································································
    # Private Method (_validate_params)
    # ··········································································

    def _validate_params(self, *, obj:core_main.Object, metadata:bool) -> None:

        ObjectDictifierParamsModel.model_validate({
            "obj":obj,
            "metadata":metadata
        })

    # ··········································································
    # Private Method (_dictify_obj_metadata)
    # ··········································································

    def _dictify_obj_metadata(self) -> None:

        self._obj_dict_metadata = {}

        if self._metadata:

            self._dictify_obj_metadata_name()
            self._dictify_obj_metadata_src_module()
            self._dictify_obj_metadata_src_file()
            self._dictify_obj_metadata_module()
            self._dictify_obj_metadata_file()
            self._dictify_obj_metadata_type()
            self._dictify_obj_metadata_type_category()
            self._dictify_obj_metadata_type_sub_category()

    # ··········································································
    # Private Method (_dictify_obj_metadata_name)
    # ··········································································

    def _dictify_obj_metadata_name(self) -> None:
        self._obj_dict_metadata["name"] = self._obj.name

    # ··········································································
    # Private Method (_dictify_obj_metadata_src_module)
    # ··········································································

    def _dictify_obj_metadata_src_module(self) -> None:
        src_module = None
        if self._obj.src_module and hasattr(self._obj.src_module, "__name__"):
            src_module = self._obj.src_module.__name__
        self._obj_dict_metadata["src_module"] = src_module

    # ··········································································
    # Private Method (_dictify_obj_metadata_src_file)
    # ··········································································

    def _dictify_obj_metadata_src_file(self) -> None:
        self._obj_dict_metadata["src_file"] = self._obj.src_file

    # ··········································································
    # Private Method (_dictify_obj_metadata_module)
    # ··········································································

    def _dictify_obj_metadata_module(self) -> None:
        module = None
        if self._obj.module and hasattr(self._obj.module, "__name__"):
            module = self._obj.module.__name__
        self._obj_dict_metadata["module"] = module

    # ··········································································
    # Private Method (_dictify_obj_metadata_file)
    # ··········································································

    def _dictify_obj_metadata_file(self) -> None:
        self._obj_dict_metadata["file"] = self._obj.file

    # ··········································································
    # Private Method (_dictify_obj_metadata_type)
    # ··········································································

    def _dictify_obj_metadata_type(self) -> None:
        self._obj_dict_metadata["type"] = self._obj.type.value

    # ··········································································
    # Private Method (_dictify_obj_metadata_type_category)
    # ··········································································

    def _dictify_obj_metadata_type_category(self) -> None:
        self._obj_dict_metadata["type_category"] =\
                self._obj.type_category.value

    # ··········································································
    # Private Method (_dictify_obj_metadata_type_sub_category)
    # ··········································································

    def _dictify_obj_metadata_type_sub_category(self) -> None:
        self._obj_dict_metadata["type_sub_category"] =\
                self._obj.type_sub_category.value

    # ··········································································
    # Private Method (_dictify_obj_body)
    # ··········································································

    def _dictify_obj_body(self) -> None:
        self._obj_dict_body = { "body": str(self._obj.body) }
