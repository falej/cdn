# ##############################################################################
# IMPORTS
# ##############################################################################

import pydictifier.core\
        .core_main as core_main
import pydictifier.dictifiers.obj_def.mod_def\
        .dictf_mod_def as dictf_mod_def
import pydictifier.dictifiers.obj_def.cls_def\
        .dictf_cls_def as dictf_cls_def
import pydictifier.dictifiers.obj_def.fn_or_mtd_bltn_def\
        .dictf_fn_or_mtd_bltn_def as dictf_fn_or_mtd_bltn_def
import pydictifier.dictifiers.obj_def.fn_or_mtd_cstm_def\
        .dictf_fn_or_mtd_cstm_def as dictf_fn_or_mtd_cstm_def
import pydictifier.dictifiers.obj_def.param_def\
        .dictf_param_def as dictf_param_def
import pydictifier.dictifiers.unknown\
        .dictf_unknown as dictf_unknown

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: Dictifier
# ------------------------------------------------------------------------------

class Dictifier:

    # ··········································································
    # Static Method (dictify)
    # ··········································································

    @staticmethod
    def dictify(*, obj:core_main.Object=None, metadata:bool=True) -> dict:

        # Dictifier Selection

        match (obj.type_sub_category):
            case core_main.ObjectTypeSubCategory.MODULE_DEFINITION:
                dictifier = dictf_mod_def.Dictifier
            case core_main.ObjectTypeSubCategory.CLASS_DEFINITION:
                dictifier = dictf_cls_def.Dictifier
            case core_main.ObjectTypeSubCategory.FN_OR_MTD_BUILTIN_DEFINITION:
                dictifier = dictf_fn_or_mtd_bltn_def.Dictifier
            case core_main.ObjectTypeSubCategory.FN_OR_MTD_CUSTOM_DEFINITION:
                dictifier = dictf_fn_or_mtd_cstm_def.Dictifier
            case core_main.ObjectTypeSubCategory.PARAMETER_DEFINITION:
                dictifier = dictf_param_def.Dictifier
            case _:
                dictifier = dictf_unknown.Dictifier

        # Object Dictify

        obj_dict = dictifier.dictify(obj=obj, metadata=metadata)

        # End

        return obj_dict
