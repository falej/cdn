# ##############################################################################
# IMPORTS
# ##############################################################################

import pydictifier.core\
        .core_main as core_main
import pydictifier.dictifiers.bltn_dtypes.dtype_numeric\
        .dictf_numeric as dictf_numeric
import pydictifier.dictifiers.bltn_dtypes.dtype_boolean\
        .dictf_boolean as dictf_boolean
import pydictifier.dictifiers.bltn_dtypes.dtype_string\
        .dictf_string as dictf_string
import pydictifier.dictifiers.bltn_dtypes.dtype_binary\
        .dictf_binary as dictf_binary
import pydictifier.dictifiers.bltn_dtypes.dtype_sequence\
        .dictf_sequence as dictf_sequence
import pydictifier.dictifiers.bltn_dtypes.dtype_set\
        .dictf_set as dictf_set
import pydictifier.dictifiers.bltn_dtypes.dtype_mapping\
        .dictf_mapping as dictf_mapping
import pydictifier.dictifiers.bltn_dtypes.dtype_none\
        .dictf_none as dictf_none
import pydictifier.dictifiers.unknown\
        .dictf_unknown as dictf_unknown

# ##############################################################################
# CLASSES
# ##############################################################################

# ------------------------------------------------------------------------------
# Class: Dictifier
# ------------------------------------------------------------------------------

class Dictifier:

    # ··········································································
    # Static Method (dictify)
    # ··········································································

    @staticmethod
    def dictify(*, obj:core_main.Object=None, metadata:bool=True) -> dict:

        # Dictifier Selection

        match (obj.type_sub_category):
            case core_main.ObjectTypeSubCategory.DATATYPE_NUMERIC:
                dictifier = dictf_numeric.Dictifier
            case core_main.ObjectTypeSubCategory.DATATYPE_BOOLEAN:
                dictifier = dictf_boolean.Dictifier
            case core_main.ObjectTypeSubCategory.DATATYPE_STRING:
                dictifier = dictf_string.Dictifier
            case core_main.ObjectTypeSubCategory.DATATYPE_BINARY:
                dictifier = dictf_binary.Dictifier
            case core_main.ObjectTypeSubCategory.DATATYPE_SEQUENCE:
                dictifier = dictf_sequence.Dictifier
            case core_main.ObjectTypeSubCategory.DATATYPE_SET:
                dictifier = dictf_set.Dictifier
            case core_main.ObjectTypeSubCategory.DATATYPE_MAPPING:
                dictifier = dictf_mapping.Dictifier
            case core_main.ObjectTypeSubCategory.DATATYPE_NONE:
                dictifier = dictf_none.Dictifier
            case _:
                dictifier = dictf_unknown.Dictifier

        # Object Dictify

        obj_dict = dictifier.dictify(obj=obj, metadata=metadata)

        # End

        return obj_dict
