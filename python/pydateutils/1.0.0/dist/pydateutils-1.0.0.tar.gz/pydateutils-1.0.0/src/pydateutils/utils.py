# ##############################################################################
# IMPORTS
# ##############################################################################

import calendar
from datetime import date
from dateutil.relativedelta import relativedelta

# ##############################################################################
# FUNCTIONS
# ##############################################################################

def day(input_date:date) -> int:

    '''
    The day of the month of the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date.day

def iso_day_of_week(input_date:date) -> int:

    '''
    The week day of the given date, in ISO format [1 = Monday, 7 = Sunday].
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date.isoweekday()

def day_of_week(input_date:date) -> int:

    '''
    The week day of the given date in format [0 = Monday, 6 = Sunday].
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date.weekday()

def day_of_week_name(input_date:date) -> str:

    '''
    The week day name (Monday, Tuesday, etc.) of the given date (full name).
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date.strftime("%A")

def day_of_week_name_short(input_date:date) -> str:

    '''
    The week day name (Mon, Tue, etc.) of the given date (short name).
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date.strftime("%a")

def day_of_month(input_date:date) -> int:

    '''
    The day of the month of the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date.day

def day_of_year(input_date:date) -> int:

    '''
    The day of the year of the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date.timetuple().tm_yday

def days_in_month(input_date:date) -> int:

    '''
    The total number of days in the month of the given date. It takes into
    account leap years. (between 28 and 31 days)
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return calendar.monthrange(input_date.year, input_date.month)[1]

def month(input_date:date) -> int:

    '''
    The month of the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date.month

def month_name(input_date:date) -> str:

    '''
    The month name (January, February, etc.) of the given date (full name).
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date.strftime("%B")

def month_name_short(input_date:date) -> str:

    '''
    The month name (Jan, Feb, etc.) of the given date (short name).
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date.strftime("%b")

def start_of_month(input_date:date) -> date:

    '''
    The date of the first day of the month of the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date + relativedelta(day=1)

def end_of_month(input_date:date) -> date:

    '''
    The date of the last day of the month of the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date + relativedelta(day=31)

def year(input_date:date) -> int:

    '''
    The year of the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date.year

def start_of_year(input_date:date) -> date:

    '''
    The date of the first day of the year of the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return date(input_date.year, 1, 1)

def end_of_year(input_date:date) -> date:

    '''
    The date of the last day of the year of the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return date(input_date.year, 12, 31)

def quarter(input_date:date) -> int:

    '''
    The quarter of the year of the given date. Can be 1, 2, 3 or 4.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return (input_date.month - 1) // 3 + 1

def quarter_name(input_date:date) -> str:

    '''
    The quarter name of the given date, in format (Q1, Q2, Q3, Q4).
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return f"Q{quarter(input_date)}"

def start_of_quarter(input_date:date) -> date:

    '''
    The date of the first day of the quarter of the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    delta_month = ((quarter(input_date) * 3) - 2)
    delta_day = 1

    return input_date + relativedelta(month=delta_month, day=delta_day)

def end_of_quarter(input_date:date) -> date:

    '''
    The date of the last day of the quarter of the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    delta_month = (quarter(input_date) * 3)
    delta_day = 31

    return input_date + relativedelta(month=delta_month, day=delta_day)

def week_of_month(input_date:date) -> int:

    '''
    Definition:
        Refers to the ordinal number of a week within a specific month.
    Range:
        Typically ranges from 1 to 4 (or sometimes 5 if the month has more than
        28 days).
    Example:
        For November 2024, the week containing November 1 is the 1st week of the
        month, and the week containing November 29 is the 5th week of the month.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return (input_date.day - 1) // 7 + 1

def iso_week_of_year(input_date:date) -> int:

    '''
    ISO-8601 Convention
        1. Week starts on Monday and ends on Sunday.
        2. Week 1 begins on January 4th, or the first Thursday of the year.
        3. A year may have 52 or 53 weeks, depending on whether the year has
           52 full weeks and an additional few days (leap years or the alignment
           of the calendar).
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date.isocalendar()[1]

def us_week_of_year(input_date:date) -> int:

    '''
    U.S. Convention
        1. Week starts on Sunday and ends on Saturday.
        2. Week 1 begins on January 1st, regardless of which day of the week it
           falls on.
        3. A partial week at the start or end of the year is still counted as
           full week.
        4. Week numbering continues sequentially from January 1 to December 31.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    day_of_year = input_date.timetuple().tm_yday
    week_number = (day_of_year - 1) // 7 + 1

    return week_number

def start_of_week(input_date:date) -> date:

    '''
    The date of the first day of the week of the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    delta_day = day_of_week(input_date) * -1

    return input_date + relativedelta(days=delta_day)

def end_of_week(input_date:date) -> date:

    '''
    The date of the last day of the week of the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    delta_day = 6 - day_of_week(input_date)

    return input_date + relativedelta(days=delta_day)

def is_leap_year(input_date:date) -> bool:

    '''
    The year of the given date is a leap year or not.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return calendar.isleap(input_date.year)

def is_start_of_month(input_date:date) -> bool:

    '''
    Checks if the given date is the first day of the month.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date.day == 1

def is_end_of_month(input_date:date) -> bool:

    '''
    Checks if the given date is the last day of the month.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return input_date.day == days_in_month(input_date)

def is_weekend(input_date:date) -> bool:

    '''
    Checks if the given date is a weekend day (Saturday or Sunday).
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return day_of_week(input_date) in [5, 6]

def is_weekday(input_date:date) -> bool:

    '''
    Checks if the given date is a weekday (Monday to Friday).
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    return not is_weekend(input_date)

def is_start_of_quarter(input_date:date) -> bool:

    '''
    Checks if the given date is the first day of the quarter.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    s_of_qtr = start_of_quarter(input_date)

    return (input_date == s_of_qtr)

def is_end_of_quarter(input_date:date) -> bool:

    '''
    Checks if the given date is the last day of the quarter.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    e_of_qtr = end_of_quarter(input_date)

    return (input_date == e_of_qtr)

def is_start_of_week(input_date:date) -> bool:

    '''
    Checks if the given date is the first day of the week.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    s_of_wk = start_of_week(input_date)

    return (input_date == s_of_wk)

def is_end_of_week(input_date:date) -> bool:

    '''
    Checks if the given date is the last day of the week.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    e_of_wk = end_of_week(input_date)

    return (input_date == e_of_wk)

def is_start_of_year(input_date:date) -> bool:

    '''
    Checks if the given date is the first day of the year.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    s_of_yr = start_of_year(input_date)

    return (input_date == s_of_yr)

def is_end_of_year(input_date:date) -> bool:

    '''
    Checks if the given date is the last day of the year.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    e_of_yr = end_of_year(input_date)

    return (input_date == e_of_yr)

def add_days(input_date:date, days:int) -> date:

    '''
    Adds the given number of days to the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    if not isinstance(days, int):
        raise TypeError("Days must be an integer")

    return input_date + relativedelta(days=days)

def add_months(input_date:date, months:int) -> date:

    '''
    Adds the given number of months to the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    if not isinstance(months, int):
        raise TypeError("Months must be an integer")

    return input_date + relativedelta(months=months)

def add_years(input_date:date, years:int) -> date:

    '''
    Adds the given number of years to the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    if not isinstance(years, int):
        raise TypeError("Years must be an integer")

    return input_date + relativedelta(years=years)

def add_weeks(input_date:date, weeks:int) -> date:

    '''
    Adds the given number of weeks to the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    if not isinstance(weeks, int):
        raise TypeError("Weeks must be an integer")

    return input_date + relativedelta(weeks=weeks)

def add_quarters(input_date:date, quarters:int) -> date:

    '''
    Adds the given number of quarters to the given date.
    '''

    if not isinstance(input_date, date):
        raise TypeError("Input must be a date object")

    if not isinstance(quarters, int):
        raise TypeError("Quarters must be an integer")

    return input_date + relativedelta(months=quarters * 3)

def compare(date_a:date, date_b:date) -> str:

    '''
    Compares two dates and returns a string indicating their relative order.
    '''

    if not isinstance(date_a, date):
        raise TypeError("Date A must be a date object")

    if not isinstance(date_b, date):
        raise TypeError("Date B must be a date object")

    if date_a < date_b:
        return "LT"

    if date_a > date_b:
        return "GT"

    return "EQ"

def date_diff_y(start_date:date, end_date:date) -> int:

    '''
    Calculates the number of whole years between start_date and end_date.
    '''

    if not isinstance(start_date, date):
        raise TypeError("Start date must be a date object")

    if not isinstance(end_date, date):
        raise TypeError("End date must be a date object")

    if compare(start_date, end_date) == "GT":
        raise ValueError("Start date must be less than or equal to end date")

    adj_incomplete_years = (end_date.month < start_date.month)
    adj_incomplete_years = adj_incomplete_years or (
            end_date.month == start_date.month and
            end_date.day < start_date.day)

    diff_years = end_date.year - start_date.year
    diff_years -= 1 if adj_incomplete_years else 0

    return diff_years

def date_diff_m(start_date:date, end_date:date) -> int:

    '''
    Calculates the number of whole months between start_date and end_date.
    '''

    if not isinstance(start_date, date):
        raise TypeError("Start date must be a date object")

    if not isinstance(end_date, date):
        raise TypeError("End date must be a date object")

    if compare(start_date, end_date) == "GT":
        raise ValueError("Start date must be less than or equal to end date")

    diff_years = end_date.year - start_date.year
    diff_months = end_date.month - start_date.month

    end_day_lt_start_day = (end_date.day < start_date.day)
    is_end_date_eom = is_end_of_month(end_date)

    adj_incomplete_months = end_day_lt_start_day and not is_end_date_eom

    total_months_diff = (diff_years * 12) + diff_months
    total_months_diff -= 1 if adj_incomplete_months else 0

    return total_months_diff

def date_diff_d(start_date:date, end_date:date) -> int:

    '''
    Calculates the number of whole days between start_date and end_date.
    '''

    if not isinstance(start_date, date):
        raise TypeError("Start date must be a date object")

    if not isinstance(end_date, date):
        raise TypeError("End date must be a date object")

    if compare(start_date, end_date) == "GT":
        raise ValueError("Start date must be less than or equal to end date")

    diff_days = (end_date - start_date).days

    return diff_days

def date_diff_ym(start_date:date, end_date:date) -> int:

    '''
    Calculates the number of whole months between start_date and
    end_date, after removing whole years.
    '''

    if not isinstance(start_date, date):
        raise TypeError("Start date must be a date object")

    if not isinstance(end_date, date):
        raise TypeError("End date must be a date object")

    if compare(start_date, end_date) == "GT":
        raise ValueError("Start date must be less than or equal to end date")

    diff_years = date_diff_y(start_date, end_date)
    adj_start_date = add_years(start_date, diff_years)

    diff_months = date_diff_m(adj_start_date, end_date)

    return diff_months

def date_diff_yd(start_date:date, end_date:date) -> int:

    '''
    Calculates the number of whole days between start_date and
    end_date, after removing whole years.
    '''

    if not isinstance(start_date, date):
        raise TypeError("Start date must be a date object")

    if not isinstance(end_date, date):
        raise TypeError("End date must be a date object")

    if compare(start_date, end_date) == "GT":
        raise ValueError("Start date must be less than or equal to end date")

    diff_years = date_diff_y(start_date, end_date)
    adj_start_date = add_years(start_date, diff_years)

    diff_days = date_diff_d(adj_start_date, end_date)

    return diff_days

def date_diff_md(start_date:date, end_date:date) -> int:

    '''
    Calculates the number of whole days between start_date and
    end_date, after removing whole years and whole months.
    '''

    if not isinstance(start_date, date):
        raise TypeError("Start date must be a date object")

    if not isinstance(end_date, date):
        raise TypeError("End date must be a date object")

    if compare(start_date, end_date) == "GT":
        raise ValueError("Start date must be less than or equal to end date")

    diff_months = date_diff_m(start_date, end_date)
    adj_start_date = add_months(start_date, diff_months)

    diff_days = date_diff_d(adj_start_date, end_date)

    return diff_days
